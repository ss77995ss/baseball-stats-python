def hello(name):
    print(f"Hello {name}! Welcome to baseball-stats-python")
